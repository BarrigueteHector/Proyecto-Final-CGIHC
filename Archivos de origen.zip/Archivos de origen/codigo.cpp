#define STB_IMAGE_IMPLEMENTATION

#include <stdio.h>
#include <string.h>
#include <cmath>
#include <vector>
#include <math.h>
#include <glew.h>
#include <glfw3.h>
#include <glm.hpp>
#include <gtc\matrix_transform.hpp>
#include <gtc\type_ptr.hpp>

#include "Window.h"
#include "Mesh.h"
#include "Shader_light.h"
#include "Camera.h"
#include "Texture.h"
#include "Sphere.h"
#include "Model.h"
#include "Skybox.h"

#include "CommonValues.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "Material.h"
const float toRadians = 3.14159265f / 180.0f;

Window mainWindow;
std::vector<Mesh*> meshList;
std::vector<Shader> shaderList;

Camera camera;

Model banqueta;
Model techo;
Model puerta;
Model portico;
Model pared_entrada;
Model hulleOSufre;
Model cocina;
Model sala;
Model comedor;
Model sofa;
Model pasto_izquierda;
Model pasto_derecha;
Model cocina_mueblesUno;
Model cocina_mueblesDos;

Texture cara_buzon;
Texture arbusto;
Texture gumball;
Texture darwin;
Texture tarjeta_giro;
Texture tarjeta_terremoto;
Texture tarjeta_escala;
Texture foto_comedor;
Texture foto_comedorDos;
Texture foto_familia;
Texture foto_unicornio;

Skybox skybox;

Material Material_brillante;
Material Material_opaco;

GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;
static double limitFPS = 1.0 / 60.0;

DirectionalLight mainLight;

// Vertex Shader
static const char* vShader = "shaders/shader_light.vert";

// Fragment Shader
static const char* fShader = "shaders/shader_light.frag";

//c�lculo del promedio de las normales para sombreado de Phong
void calcAverageNormals(unsigned int* indices, unsigned int indiceCount, GLfloat* vertices, unsigned int verticeCount, unsigned int vLength, unsigned int normalOffset)
{
	for (size_t i = 0; i < indiceCount; i += 3)
	{
		unsigned int in0 = indices[i] * vLength;
		unsigned int in1 = indices[i + 1] * vLength;
		unsigned int in2 = indices[i + 2] * vLength;
		glm::vec3 v1(vertices[in1] - vertices[in0], vertices[in1 + 1] - vertices[in0 + 1], vertices[in1 + 2] - vertices[in0 + 2]);
		glm::vec3 v2(vertices[in2] - vertices[in0], vertices[in2 + 1] - vertices[in0 + 1], vertices[in2 + 2] - vertices[in0 + 2]);
		glm::vec3 normal = glm::cross(v1, v2);
		normal = glm::normalize(normal);

		in0 += normalOffset; in1 += normalOffset; in2 += normalOffset;
		vertices[in0] += normal.x; vertices[in0 + 1] += normal.y; vertices[in0 + 2] += normal.z;
		vertices[in1] += normal.x; vertices[in1 + 1] += normal.y; vertices[in1 + 2] += normal.z;
		vertices[in2] += normal.x; vertices[in2 + 1] += normal.y; vertices[in2 + 2] += normal.z;
	}

	for (size_t i = 0; i < verticeCount / vLength; i++)
	{
		unsigned int nOffset = i * vLength + normalOffset;
		glm::vec3 vec(vertices[nOffset], vertices[nOffset + 1], vertices[nOffset + 2]);
		vec = glm::normalize(vec);
		vertices[nOffset] = vec.x; vertices[nOffset + 1] = vec.y; vertices[nOffset + 2] = vec.z;
	}
}

void CreateObjects()
{
	unsigned int indices_buzon[] = {
		0, 3, 1,
		1, 3, 2,
		2, 3, 0,
		0, 1, 2
	};
	GLfloat vertices_buzon[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_arbusto[] = {
		0, 3, 1,
		1, 3, 2,
		2, 3, 0,
		0, 1, 2
	};
	GLfloat vertices_arbusto[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_gumball[] = {
		0, 3, 1,
		1, 3, 2,
		2, 3, 0,
		0, 1, 2
	};
	GLfloat vertices_gumball[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_darwin[] = {
			0, 3, 1,
			1, 3, 2,
			2, 3, 0,
			0, 1, 2
	};
	GLfloat vertices_darwin[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_giro[] = {
			0, 3, 1,
			1, 3, 2,
			2, 3, 0,
			0, 1, 2
	};
	GLfloat vertices_giro[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_terremoto[] = {
			0, 3, 1,
			1, 3, 2,
			2, 3, 0,
			0, 1, 2
	};
	GLfloat vertices_terremoto[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_escala[] = {
			0, 3, 1,
			1, 3, 2,
			2, 3, 0,
			0, 1, 2
	};
	GLfloat vertices_escala[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_fotoComedor[] = {
			0, 3, 1,
			1, 3, 2,
			2, 3, 0,
			0, 1, 2
	};
	GLfloat vertices_fotoComedor[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_fotoComedorDos[] = {
				0, 3, 1,
				1, 3, 2,
				2, 3, 0,
				0, 1, 2
	};
	GLfloat vertices_fotoComedorDos[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_fotoFamilia[] = {
				0, 3, 1,
				1, 3, 2,
				2, 3, 0,
				0, 1, 2
	};
	GLfloat vertices_fotoFamilia[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	unsigned int indices_fotoUnicornio[] = {
				0, 3, 1,
				1, 3, 2,
				2, 3, 0,
				0, 1, 2
	};
	GLfloat vertices_fotoUnicornio[] = {
		//	x      y      z			u	  v			nx	  ny    nz
		-0.5f, 0.0f, 0.5f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, 0.5f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		0.5f, 0.0f, -0.5f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f
	};

	Mesh* obj0 = new Mesh();
	obj0->CreateMesh(vertices_buzon, indices_buzon, 32, 6);
	meshList.push_back(obj0);

	Mesh* obj1 = new Mesh();
	obj1->CreateMesh(vertices_arbusto, indices_arbusto, 32, 6);
	meshList.push_back(obj1);

	Mesh* obj2 = new Mesh();
	obj2->CreateMesh(vertices_gumball, indices_gumball, 32, 6);
	meshList.push_back(obj2); 
	
	Mesh* obj3 = new Mesh();
	obj3->CreateMesh(vertices_darwin, indices_darwin, 32, 6);
	meshList.push_back(obj3);

	Mesh* obj4 = new Mesh();
	obj4->CreateMesh(vertices_giro, indices_giro, 32, 6);
	meshList.push_back(obj4);

	Mesh* obj5 = new Mesh();
	obj5->CreateMesh(vertices_terremoto, indices_terremoto, 32, 6);
	meshList.push_back(obj5);

	Mesh* obj6 = new Mesh();
	obj6->CreateMesh(vertices_escala, indices_escala, 32, 6);
	meshList.push_back(obj6);

	Mesh* obj7 = new Mesh();
	obj7->CreateMesh(vertices_fotoComedor, indices_fotoComedor, 32, 6);
	meshList.push_back(obj7);

	Mesh* obj8 = new Mesh();
	obj8->CreateMesh(vertices_fotoComedorDos, indices_fotoComedorDos, 32, 6);
	meshList.push_back(obj8);

	Mesh* obj9 = new Mesh();
	obj9->CreateMesh(vertices_fotoFamilia, indices_fotoFamilia, 32, 6);
	meshList.push_back(obj9);

	Mesh* obj10 = new Mesh();
	obj10->CreateMesh(vertices_fotoUnicornio, indices_fotoUnicornio, 32, 6);
	meshList.push_back(obj10);
}

void CreateShaders()
{
	Shader *shader1 = new Shader();
	shader1->CreateFromFiles(vShader, fShader);
	shaderList.push_back(*shader1);
}

int main()
{
	mainWindow = Window(1366, 768); 
	mainWindow.Initialise();

	CreateObjects();
	CreateShaders();

	camera = Camera(glm::vec3(0.0f, 12.0f, 20.0f), glm::vec3(0.0f, 1.0f, 0.0f), -60.0f, 0.0f, 0.5f, 0.5f);

	banqueta = Model();
	banqueta.LoadModel("Models/banqueta.obj");
	techo = Model();
	techo.LoadModel("Models/techo.obj");
	puerta = Model();
	puerta.LoadModel("Models/puerta.obj");
	portico = Model();
	portico.LoadModel("Models/portico.obj");
	pared_entrada = Model();
	pared_entrada.LoadModel("Models/pared_entrada.obj");
	hulleOSufre = Model();
	hulleOSufre.LoadModel("Models/hulleOSufre.obj");
	sala = Model();
	sala.LoadModel("Models/sala.obj");
	sofa = Model();
	sofa.LoadModel("Models/sofa.obj");
	comedor = Model();
	comedor.LoadModel("Models/comedor.obj");
	cocina = Model();
	cocina.LoadModel("Models/cocina.obj");
	cocina_mueblesUno = Model();
	cocina_mueblesUno.LoadModel("Models/cocina_setUno.obj");
	cocina_mueblesDos = Model();
	cocina_mueblesDos.LoadModel("Models/cocina_setDos.obj");
	pasto_izquierda = Model();
	pasto_izquierda.LoadModel("Models/pasto_izquierda.obj");
	pasto_derecha = Model();
	pasto_derecha.LoadModel("Models/pasto_derecha.obj");

	cara_buzon = Texture("Textures/cara_buzon.tga");
	cara_buzon.LoadTextureA();
	arbusto = Texture("Textures/arbusto_alfa.tga");
	arbusto.LoadTextureA();
	gumball = Texture("Textures/gumballTexture.tga");
	gumball.LoadTextureA();
	darwin = Texture("Textures/darwinTexture.tga");
	darwin.LoadTextureA();
	tarjeta_giro = Texture("Textures/carta_g.png");
	tarjeta_giro.LoadTextureA();
	tarjeta_terremoto = Texture("Textures/carta_h.png");
	tarjeta_terremoto.LoadTextureA();
	tarjeta_escala = Texture("Textures/carta_t.png");
	tarjeta_escala.LoadTextureA();
	foto_comedor = Texture("Textures/foto_comedor.png");
	foto_comedor.LoadTextureA();
	foto_comedorDos = Texture("Textures/foto_comedorDos.png");
	foto_comedorDos.LoadTextureA();
	foto_familia = Texture("Textures/foto_familia.png");
	foto_familia.LoadTextureA();
	foto_unicornio = Texture("Textures/foto_unicornio.png");
	foto_unicornio.LoadTextureA();

	std::vector<std::string> skyboxFaces;
	
	// ******************* Skybox *******************
	skyboxFaces.push_back("Textures/Skybox/ladosDos.tga");
	skyboxFaces.push_back("Textures/Skybox/ladosDos.tga");
	skyboxFaces.push_back("Textures/Skybox/ladosDos.tga");
	skyboxFaces.push_back("Textures/Skybox/arriba.tga");
	skyboxFaces.push_back("Textures/Skybox/ladosDos.tga");
	skyboxFaces.push_back("Textures/Skybox/ladosDos.tga");
	
	skybox = Skybox(skyboxFaces);

	Material_brillante = Material(4.0f, 256);
	Material_opaco = Material(0.3f, 4);

	mainLight = DirectionalLight(1.0f, 1.0f, 1.0f,
		0.5f, 0.5f,
		1.0f, 0.0f, -1.0f);
	
	GLuint uniformProjection = 0, uniformModel = 0, uniformView = 0, uniformEyePosition = 0,uniformSpecularIntensity = 0, uniformShininess = 0, uniformTextureOffset=0;
	GLuint uniformColor = 0;
	glm::mat4 projection = glm::perspective(45.0f, (GLfloat)mainWindow.getBufferWidth() / mainWindow.getBufferHeight(), 0.1f, 1000.0f);
	
	while (!mainWindow.getShouldClose())
	{
		GLfloat now = glfwGetTime();
		deltaTime = now - lastTime;
		deltaTime += (now - lastTime) / limitFPS;
		lastTime = now;
		
		//Recibir eventos del usuario
		glfwPollEvents();
		camera.keyControl(mainWindow.getsKeys(), deltaTime);
		camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		skybox.DrawSkybox(camera.calculateViewMatrix(), projection);
		shaderList[0].UseShader();
		uniformModel = shaderList[0].GetModelLocation();
		uniformProjection = shaderList[0].GetProjectionLocation();
		uniformView = shaderList[0].GetViewLocation();
		uniformEyePosition = shaderList[0].GetEyePositionLocation();
		uniformColor = shaderList[0].getColorLocation();
		uniformTextureOffset = shaderList[0].getOffsetLocation();

		//informaci�n en el shader de intensidad especular y brillo
		uniformSpecularIntensity = shaderList[0].GetSpecularIntensityLocation();
		uniformShininess = shaderList[0].GetShininessLocation();

		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));
		glUniform3f(uniformEyePosition, camera.getCameraPosition().x, camera.getCameraPosition().y, camera.getCameraPosition().z);

		shaderList[0].SetDirectionalLight(&mainLight);
		
		glm::mat4 model(1.0);
		glm::vec3 color = glm::vec3(1.0f, 1.0f, 1.0f);
		
		// --------------------- FOTOGRAFIAS ---------------------
		// ****************** FOTO COMEDOR ******************
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(3.0f, 16.0f, -40.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::rotate(model, -90 * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::scale(model, glm::vec3(3.0f, 3.0f, 3.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));
		foto_comedor.UseTexture();
		meshList[7]->RenderMesh();
		// ****************** FOTO COMEDOR DOS ******************
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-6.0f, 16.0f, -57.5f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::scale(model, glm::vec3(4.0f, 4.0f, 4.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));
		foto_comedorDos.UseTexture();
		meshList[8]->RenderMesh();
		// ****************** FOTO FAMILIA ******************
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(24.0f, 16.0f, -25.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::rotate(model, -90 * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::scale(model, glm::vec3(5.0f, 5.0f, 5.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));
		foto_familia.UseTexture();
		meshList[9]->RenderMesh();
		// ****************** FOTO UNICORNIO ******************
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(24.0f, 16.0f, -13.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::rotate(model, -90 * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::scale(model, glm::vec3(3.0f, 3.0f, 3.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));
		foto_unicornio.UseTexture();
		meshList[10]->RenderMesh();

		// --------------------- BANQUETA ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		banqueta.RenderModel();
		// --------------------- TECHO ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		techo.RenderModel();
		// --------------------- PUERTA ---------------------
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(13.12f, 11.543f, -10.7f));
		// ***** ANIMACION *****
		model = glm::rotate(model, glm::radians(mainWindow.getPuerta()), glm::vec3(0.0f, -1.0f, 0.0f)); //P
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		puerta.RenderModel();
		// --------------------- PORTICO ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		portico.RenderModel();
		// --------------------- PARED ENTRADA ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		pared_entrada.RenderModel();
		// --------------------- HULLE O SUFRE ---------------------
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(0.0f, 1.5f, 3.0f));
		model = glm::scale(model, glm::vec3(0.8f, 0.8f, 0.8f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		hulleOSufre.RenderModel();
		// --------------------- SALA ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		sala.RenderModel();
		// --------------------- COMEDOR ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		comedor.RenderModel();
		// --------------------- SOFA ---------------------
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(0.0f, 9.5f, -30.7f));
		model = glm::rotate(model, glm::radians(mainWindow.getGiro()), glm::vec3(0.0f, 1.0f, 0.0f)); //G
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		sofa.RenderModel();
		// --------------------- COCINA ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		cocina.RenderModel();
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		cocina_mueblesUno.RenderModel();
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		cocina_mueblesDos.RenderModel();
		// --------------------- PASTO IZQUIERDA ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		pasto_izquierda.RenderModel();
		// --------------------- PASTO DERECHA ---------------------
		model = glm::mat4(1.0);
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		pasto_derecha.RenderModel();

		// ********************* TEXTURAS (con canal alfa) *********************
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		// ------------------ CARA BUZON ------------------
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-3.056f, 8.037f, 51.12f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::rotate(model, -40 * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::scale(model, glm::vec3(1.25f, 2.0f, 1.9f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		cara_buzon.UseTexture();
		meshList[0]->RenderMesh();
		
		// ------------------ ARBUSTO ------------------
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(21.0f, 4.0f, 2.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::scale(model, glm::vec3(12.0f, 12.0f, 12.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		arbusto.UseTexture();
		meshList[1]->RenderMesh();
		
		// ------------------ GUMBALL ------------------
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-3.0f, 10.0f, -25.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::scale(model, glm::vec3(4.5f, 4.5f, 4.5f));
		// ***** ANIMACION *****
		model = glm::translate(model, glm::vec3(mainWindow.getTerremoto(), 0.0f, 0.0f)); // H
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		gumball.UseTexture();
		meshList[2]->RenderMesh();
		
		// ------------------ DARWIN ------------------
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(2.0f, 10.0f, -25.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::scale(model, glm::vec3(4.5f, 4.5f, 4.5f));
		// ***** ANIMACION *****
		model = glm::scale(model, glm::vec3(mainWindow.getEscala(), mainWindow.getEscala(), mainWindow.getEscala())); //T
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		darwin.UseTexture();
		meshList[3]->RenderMesh();

		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(2.0f, 7.9f, -20.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		tarjeta_giro.UseTexture();
		meshList[4]->RenderMesh();

		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-5.0f, 7.9f, -24.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		tarjeta_terremoto.UseTexture();
		meshList[5]->RenderMesh();

		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(2.0f, 7.9f, -24.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		tarjeta_escala.UseTexture();
		meshList[6]->RenderMesh();

		glDisable(GL_BLEND);		

		glUseProgram(0);

		mainWindow.swapBuffers();
	}

	return 0;
}